"""Direct tests for deterministic PS-CA resource scaffold construction."""

from __future__ import annotations

from fhir_bundle_builder.specifications.psca import PscaAssetQuery, PscaAssetRepository
from fhir_bundle_builder.workflows.psca_bundle_builder_workflow.build_plan_builder import (
    build_psca_build_plan,
)
from fhir_bundle_builder.workflows.psca_bundle_builder_workflow.models import (
    BundleRequestInput,
    NormalizedBuildRequest,
    ProfileReferenceInput,
    ResourceConstructionRepairDirective,
    SpecificationSelection,
    WorkflowDefaults,
)
from fhir_bundle_builder.workflows.psca_bundle_builder_workflow.resource_construction_builder import (
    build_psca_resource_construction_result,
)
from fhir_bundle_builder.workflows.psca_bundle_builder_workflow.schematic_builder import (
    build_psca_bundle_schematic,
)


def test_psca_resource_construction_builder_generates_scaffolds_and_registry() -> None:
    repository = PscaAssetRepository()
    normalized_assets = repository.load_foundation_context(PscaAssetQuery())
    schematic = build_psca_bundle_schematic(normalized_assets)
    plan = build_psca_build_plan(schematic)
    normalized_request = NormalizedBuildRequest(
        stage_id="request_normalization",
        status="placeholder_complete",
        summary="Test normalized request.",
        placeholder_note="Test artifact.",
        source_refs=[],
        specification=SpecificationSelection(),
        patient_profile=ProfileReferenceInput(
            profile_id="patient-resource-test",
            display_name="Resource Test Patient",
        ),
        provider_profile=ProfileReferenceInput(
            profile_id="provider-resource-test",
            display_name="Resource Test Provider",
        ),
        request=BundleRequestInput(
            request_text="Create a deterministic resource construction result for testing.",
            scenario_label="pytest-resource",
        ),
        workflow_defaults=WorkflowDefaults(
            bundle_type="document",
            specification_mode="normalized-asset-foundation",
            validation_mode="foundational_dual_channel",
            resource_construction_mode="deterministic_content_enriched_foundation",
        ),
        run_label="pytest-resource:ca.infoway.io.psca:2.1.1-DFT",
    )

    construction = build_psca_resource_construction_result(plan, schematic, normalized_request)

    assert construction.construction_mode == "deterministic_content_enriched"
    assert [step.step_id for step in construction.step_results] == [step.step_id for step in plan.steps]
    assert len(construction.step_results) == 11
    assert len(construction.resource_registry) == 8

    steps = {step.step_id: step for step in construction.step_results}
    registry = {entry.placeholder_id: entry for entry in construction.resource_registry}

    assert steps["build-composition-1-scaffold"].execution_status == "scaffold_created"
    assert steps["finalize-composition-1-medications-section"].execution_status == "scaffold_updated"
    assert steps["finalize-composition-1-allergies-section"].execution_status == "scaffold_updated"
    assert steps["finalize-composition-1-problems-section"].execution_status == "scaffold_updated"

    practitioner_role = registry["practitionerrole-1"].current_scaffold.fhir_scaffold
    practitioner = registry["practitioner-1"].current_scaffold.fhir_scaffold
    organization = registry["organization-1"].current_scaffold.fhir_scaffold
    assert practitioner_role["practitioner"]["reference"] == "Practitioner/practitioner-1"
    assert practitioner_role["organization"]["reference"] == "Organization/organization-1"
    assert practitioner_role["code"][0]["text"] == "document-author"
    assert practitioner["active"] is True
    assert practitioner["identifier"][0]["value"] == "provider-resource-test"
    assert practitioner["name"][0]["text"] == "Resource Test Provider"
    assert "name" not in organization

    medication = registry["medicationrequest-1"].current_scaffold.fhir_scaffold
    allergy = registry["allergyintolerance-1"].current_scaffold.fhir_scaffold
    condition = registry["condition-1"].current_scaffold.fhir_scaffold
    patient = registry["patient-1"].current_scaffold.fhir_scaffold
    section_titles = {section.section_key: section.title for section in schematic.section_scaffolds}
    assert medication["subject"]["reference"] == "Patient/patient-1"
    assert medication["status"] == "draft"
    assert medication["intent"] == "proposal"
    assert medication["medicationCodeableConcept"]["text"] == (
        f"{section_titles['medications']} placeholder for pytest-resource"
    )
    assert allergy["patient"]["reference"] == "Patient/patient-1"
    assert allergy["clinicalStatus"]["coding"][0]["code"] == "active"
    assert allergy["verificationStatus"]["coding"][0]["code"] == "unconfirmed"
    assert allergy["code"]["text"] == f"{section_titles['allergies']} placeholder for pytest-resource"
    assert condition["subject"]["reference"] == "Patient/patient-1"
    assert condition["clinicalStatus"]["coding"][0]["code"] == "active"
    assert condition["verificationStatus"]["coding"][0]["code"] == "provisional"
    assert condition["code"]["text"] == f"{section_titles['problems']} placeholder for pytest-resource"
    assert patient["active"] is True
    assert patient["identifier"][0]["value"] == "patient-resource-test"
    assert patient["name"][0]["text"] == "Resource Test Patient"

    composition_scaffold = steps["build-composition-1-scaffold"].resource_scaffold.fhir_scaffold
    assert composition_scaffold["type"]["coding"][0]["system"] == "http://loinc.org"
    assert composition_scaffold["type"]["coding"][0]["code"] == "60591-5"
    assert composition_scaffold["status"] == "final"
    assert composition_scaffold["title"] == "PS-CA document bundle skeleton - pytest-resource"
    assert composition_scaffold["subject"]["reference"] == "Patient/patient-1"
    assert composition_scaffold["author"][0]["reference"] == "PractitionerRole/practitionerrole-1"
    assert composition_scaffold["section"] == []
    assert steps["build-patient-1"].resource_scaffold.deferred_paths == ["gender", "birthDate"]
    assert steps["build-practitioner-1"].resource_scaffold.deferred_paths == ["telecom", "address", "qualification"]
    assert steps["build-organization-1"].resource_scaffold.deferred_paths == ["identifier", "name"]
    assert steps["build-practitionerrole-1"].resource_scaffold.deferred_paths == [
        "specialty",
        "telecom",
        "period",
        "availableTime",
    ]
    assert any(
        evidence.target_path == "identifier[0].value" and evidence.source_detail == "patient_profile.profile_id"
        for evidence in steps["build-patient-1"].deterministic_value_evidence
    )
    assert any(
        evidence.target_path == "identifier[0].value" and evidence.source_detail == "provider_profile.profile_id"
        for evidence in steps["build-practitioner-1"].deterministic_value_evidence
    )
    assert any(
        evidence.target_path == "name[0].text" and evidence.source_detail == "provider_profile.display_name"
        for evidence in steps["build-practitioner-1"].deterministic_value_evidence
    )
    assert any(
        evidence.target_path == "code[0].text" and evidence.source_detail == "role"
        for evidence in steps["build-practitionerrole-1"].deterministic_value_evidence
    )
    assert any(
        evidence.target_path == "title" and evidence.source_detail == "bundle_intent + scenario_label"
        for evidence in steps["build-composition-1-scaffold"].deterministic_value_evidence
    )
    assert any(
        evidence.target_path == "medicationCodeableConcept.text"
        for evidence in steps["build-medicationrequest-1"].deterministic_value_evidence
    )

    finalized_composition = registry["composition-1"].current_scaffold
    assert finalized_composition.scaffold_state == "sections_attached"
    assert finalized_composition.source_step_ids == [
        "build-composition-1-scaffold",
        "finalize-composition-1-medications-section",
        "finalize-composition-1-allergies-section",
        "finalize-composition-1-problems-section",
    ]
    assert [section["title"] for section in finalized_composition.fhir_scaffold["section"]] == [
        section.title for section in schematic.section_scaffolds
    ]
    assert [
        section["entry"][0]["reference"] for section in finalized_composition.fhir_scaffold["section"]
    ] == [
        "MedicationRequest/medicationrequest-1",
        "AllergyIntolerance/allergyintolerance-1",
        "Condition/condition-1",
    ]
    assert (
        finalized_composition.fhir_scaffold["section"][0]["code"]["coding"][0]["display"]
        == schematic.section_scaffolds[0].title
    )


def test_psca_resource_construction_builder_supports_targeted_patient_repair() -> None:
    repository = PscaAssetRepository()
    normalized_assets = repository.load_foundation_context(PscaAssetQuery())
    schematic = build_psca_bundle_schematic(normalized_assets)
    plan = build_psca_build_plan(schematic)
    normalized_request = _build_normalized_request("pytest-targeted-patient")
    full_result = build_psca_resource_construction_result(plan, schematic, normalized_request)
    repair_directive = ResourceConstructionRepairDirective(
        directive_basis="validation_finding_code_map",
        scope="build_step_subset",
        trigger_finding_codes=["bundle.patient_identity_content_present"],
        target_step_ids=["build-patient-1"],
        target_placeholder_ids=["patient-1"],
        rationale="Rerun the patient anchor step to restore deterministic patient identity content.",
    )

    targeted_result = build_psca_resource_construction_result(
        plan,
        schematic,
        normalized_request,
        prior_result=full_result,
        repair_directive=repair_directive,
    )

    assert targeted_result.execution_scope == "targeted_repair"
    assert targeted_result.applied_repair_directive == repair_directive
    assert [step.step_id for step in targeted_result.step_results] == ["build-patient-1"]
    assert targeted_result.regenerated_placeholder_ids == ["patient-1"]
    assert "patient-1" not in targeted_result.reused_placeholder_ids
    assert set(targeted_result.reused_placeholder_ids) == {
        "practitioner-1",
        "organization-1",
        "practitionerrole-1",
        "composition-1",
        "medicationrequest-1",
        "allergyintolerance-1",
        "condition-1",
    }
    registry = {entry.placeholder_id: entry for entry in targeted_result.resource_registry}
    assert set(registry) == {
        "patient-1",
        "practitioner-1",
        "organization-1",
        "practitionerrole-1",
        "composition-1",
        "medicationrequest-1",
        "allergyintolerance-1",
        "condition-1",
    }
    assert registry["patient-1"].latest_step_id == "build-patient-1"
    assert registry["patient-1"].current_scaffold.fhir_scaffold["name"][0]["text"] == "Resource Test Patient"
    assert registry["composition-1"].current_scaffold.source_step_ids == [
        "build-composition-1-scaffold",
        "finalize-composition-1-medications-section",
        "finalize-composition-1-allergies-section",
        "finalize-composition-1-problems-section",
    ]


def test_psca_resource_construction_builder_supports_targeted_composition_section_repair() -> None:
    repository = PscaAssetRepository()
    normalized_assets = repository.load_foundation_context(PscaAssetQuery())
    schematic = build_psca_bundle_schematic(normalized_assets)
    plan = build_psca_build_plan(schematic)
    normalized_request = _build_normalized_request("pytest-targeted-composition")
    full_result = build_psca_resource_construction_result(plan, schematic, normalized_request)
    repair_directive = ResourceConstructionRepairDirective(
        directive_basis="validation_finding_code_map",
        scope="build_step_subset",
        trigger_finding_codes=["bundle.composition_allergies_section_present"],
        target_step_ids=["finalize-composition-1-allergies-section"],
        target_placeholder_ids=["composition-1"],
        rationale="Rerun allergies section finalization to reattach the deterministic allergies section block.",
    )

    targeted_result = build_psca_resource_construction_result(
        plan,
        schematic,
        normalized_request,
        prior_result=full_result,
        repair_directive=repair_directive,
    )

    assert targeted_result.execution_scope == "targeted_repair"
    assert targeted_result.applied_repair_directive == repair_directive
    assert [step.step_id for step in targeted_result.step_results] == [
        "finalize-composition-1-allergies-section"
    ]
    assert targeted_result.regenerated_placeholder_ids == ["composition-1"]
    assert "composition-1" not in targeted_result.reused_placeholder_ids
    registry = {entry.placeholder_id: entry for entry in targeted_result.resource_registry}
    assert len(registry["composition-1"].current_scaffold.fhir_scaffold["section"]) == 3
    assert [
        section["title"] for section in registry["composition-1"].current_scaffold.fhir_scaffold["section"]
    ] == [section.title for section in schematic.section_scaffolds]
    assert registry["composition-1"].current_scaffold.source_step_ids == [
        "build-composition-1-scaffold",
        "finalize-composition-1-medications-section",
        "finalize-composition-1-allergies-section",
        "finalize-composition-1-problems-section",
    ]


def _build_normalized_request(scenario_label: str) -> NormalizedBuildRequest:
    return NormalizedBuildRequest(
        stage_id="request_normalization",
        status="placeholder_complete",
        summary="Test normalized request.",
        placeholder_note="Test artifact.",
        source_refs=[],
        specification=SpecificationSelection(),
        patient_profile=ProfileReferenceInput(
            profile_id="patient-resource-test",
            display_name="Resource Test Patient",
        ),
        provider_profile=ProfileReferenceInput(
            profile_id="provider-resource-test",
            display_name="Resource Test Provider",
        ),
        request=BundleRequestInput(
            request_text="Create a deterministic resource construction result for testing.",
            scenario_label=scenario_label,
        ),
        workflow_defaults=WorkflowDefaults(
            bundle_type="document",
            specification_mode="normalized-asset-foundation",
            validation_mode="foundational_dual_channel",
            resource_construction_mode="deterministic_content_enriched_foundation",
        ),
        run_label=f"{scenario_label}:ca.infoway.io.psca:2.1.1-DFT",
    )
