"""Typed models for the PS-CA workflow skeleton."""

from __future__ import annotations

from typing import Any
from typing import Literal

from pydantic import BaseModel, Field

from fhir_bundle_builder.specifications.psca import PscaNormalizedAssetContext
from fhir_bundle_builder.validation.models import (
    PlaceholderTraceabilitySummary,
    StandardsValidationResult,
    ValidationChannel,
    ValidationEvidence,
    ValidationSeverity,
    ValidationStatus,
    WorkflowValidationResult,
)


class SpecificationSelection(BaseModel):
    """Top-level selection of the target implementation guide."""

    package_id: str = Field(
        default="ca.infoway.io.psca",
        description="FHIR package identifier for the target implementation guide.",
    )
    version: str = Field(
        default="2.1.1-DFT",
        description="Package version for the selected implementation guide.",
    )
    fhir_version: str = Field(
        default="4.0.1",
        description="FHIR core version expected by this package.",
    )


class ProfileReferenceInput(BaseModel):
    """Structured placeholder reference for a reusable profile."""

    profile_id: str = Field(
        ...,
        description="Stable identifier for the selected reusable profile.",
    )
    display_name: str = Field(
        ...,
        description="Human-readable label shown in Dev UI and traces.",
    )
    source_type: Literal["stub", "provider_management", "patient_management"] = Field(
        default="stub",
        description="Current profile source type for this workflow skeleton.",
    )


class ProviderIdentityInput(BaseModel):
    """Structured provider identity supplied by an upstream provider-management layer."""

    provider_id: str = Field(
        ...,
        description="Stable identifier for the selected provider.",
    )
    display_name: str = Field(
        ...,
        description="Human-readable provider label shown in Dev UI and traces.",
    )
    source_type: Literal["stub", "provider_management"] = Field(
        default="stub",
        description="Source type for the upstream provider identity context.",
    )


class ProviderOrganizationInput(BaseModel):
    """Structured organization available to the selected provider."""

    organization_id: str = Field(
        ...,
        description="Stable identifier for the organization.",
    )
    display_name: str = Field(
        ...,
        description="Human-readable organization label.",
    )


class ProviderRoleRelationshipInput(BaseModel):
    """Structured relationship linking a provider to an organization and role label."""

    relationship_id: str = Field(
        ...,
        description="Stable identifier for the provider-role relationship.",
    )
    organization_id: str = Field(
        ...,
        description="Identifier of the organization linked by this provider-role relationship.",
    )
    role_label: str = Field(
        ...,
        description="Deterministic provider-role label available to downstream support-resource construction.",
    )


class ProviderContextInput(BaseModel):
    """Structured provider/org/role context supplied by an upstream provider-management layer."""

    provider: ProviderIdentityInput
    organizations: list[ProviderOrganizationInput] = Field(default_factory=list)
    provider_role_relationships: list[ProviderRoleRelationshipInput] = Field(default_factory=list)
    selected_provider_role_relationship_id: str | None = Field(
        default=None,
        description="Explicit selected provider-role relationship to use for this workflow run.",
    )


class PatientIdentityInput(BaseModel):
    """Structured patient identity supplied by an upstream patient-management layer."""

    patient_id: str = Field(
        ...,
        description="Stable identifier for the selected patient.",
    )
    display_name: str = Field(
        ...,
        description="Human-readable patient label shown in Dev UI and traces.",
    )
    source_type: Literal["stub", "patient_management"] = Field(
        default="stub",
        description="Source type for the upstream patient identity context.",
    )
    administrative_gender: Literal["female", "male", "other", "unknown"] | None = Field(
        default=None,
        description="Administrative gender available from structured upstream context.",
    )
    birth_date: str | None = Field(
        default=None,
        description="Birth date from structured upstream context in YYYY-MM-DD format when available.",
    )


class PatientConditionInput(BaseModel):
    """Structured patient condition available to the workflow."""

    condition_id: str = Field(
        ...,
        description="Stable identifier for the condition profile item.",
    )
    display_text: str = Field(
        ...,
        description="Deterministic condition label available to downstream construction.",
    )


class PatientMedicationInput(BaseModel):
    """Structured patient medication available to the workflow."""

    medication_id: str = Field(
        ...,
        description="Stable identifier for the medication profile item.",
    )
    display_text: str = Field(
        ...,
        description="Deterministic medication label available to downstream construction.",
    )


class PatientAllergyInput(BaseModel):
    """Structured patient allergy available to the workflow."""

    allergy_id: str = Field(
        ...,
        description="Stable identifier for the allergy profile item.",
    )
    display_text: str = Field(
        ...,
        description="Deterministic allergy label available to downstream construction.",
    )


class NormalizedPlannedMedicationEntry(BaseModel):
    """Deterministic bounded medication-entry selection for the current workflow run."""

    placeholder_id: Literal["medicationrequest-1", "medicationrequest-2"]
    source_medication_index: int = Field(
        ...,
        description="Zero-based index into the normalized structured medication list.",
    )
    medication_id: str = Field(
        ...,
        description="Stable identifier of the structured medication item selected for this placeholder.",
    )
    display_text: str = Field(
        ...,
        description="Deterministic medication label selected for this placeholder.",
    )


class PatientContextInput(BaseModel):
    """Structured patient/clinical profile context supplied by an upstream layer."""

    patient: PatientIdentityInput
    conditions: list[PatientConditionInput] = Field(default_factory=list)
    medications: list[PatientMedicationInput] = Field(default_factory=list)
    allergies: list[PatientAllergyInput] = Field(default_factory=list)


class BundleRequestInput(BaseModel):
    """Structured request details for the workflow run."""

    request_text: str = Field(
        ...,
        description="Natural-language request describing the intended PS-CA bundle scenario.",
    )
    bundle_intent: str = Field(
        default="PS-CA document bundle skeleton",
        description="Short label for the requested bundle intent.",
    )
    scenario_label: str = Field(
        default="initial-dev-ui-slice",
        description="Scenario label to make repeated Dev UI runs easier to identify.",
    )


class WorkflowOptionsInput(BaseModel):
    """Options that affect inspectability of the workflow run."""

    include_example_bundle_inventory: bool = Field(
        default=True,
        description="Whether to inspect one PS-CA example bundle and expose its entry inventory.",
    )
    example_bundle_filename: str = Field(
        default="Bundle1Example.json",
        description="The example bundle file to inspect for placeholder planning.",
    )
    emit_placeholder_warnings: bool = Field(
        default=True,
        description="Whether placeholder artifacts should include explicit stub warnings.",
    )


class WorkflowBuildInput(BaseModel):
    """Structured top-level workflow input."""

    specification: SpecificationSelection = Field(default_factory=SpecificationSelection)
    patient_profile: ProfileReferenceInput = Field(
        default_factory=lambda: ProfileReferenceInput(
            profile_id="patient-profile-stub",
            display_name="Default patient profile stub",
        )
    )
    patient_context: PatientContextInput | None = None
    provider_profile: ProfileReferenceInput = Field(
        default_factory=lambda: ProfileReferenceInput(
            profile_id="provider-profile-stub",
            display_name="Default provider profile stub",
        )
    )
    provider_context: ProviderContextInput | None = None
    request: BundleRequestInput = Field(
        default_factory=lambda: BundleRequestInput(
            request_text="Create a placeholder PS-CA bundle workflow run for Dev UI inspection."
        )
    )
    workflow_options: WorkflowOptionsInput = Field(default_factory=WorkflowOptionsInput)


class StageArtifact(BaseModel):
    """Common inspectability fields for all stage artifacts."""

    stage_id: str
    status: Literal["placeholder_complete", "placeholder_warning"]
    summary: str
    placeholder_note: str
    source_refs: list[str] = Field(default_factory=list)


class WorkflowDefaults(BaseModel):
    """Defaults chosen during request normalization."""

    bundle_type: str
    specification_mode: Literal["normalized-asset-foundation"]
    validation_mode: Literal["foundational_dual_channel"]
    resource_construction_mode: Literal["deterministic_content_enriched_foundation"]


class NormalizedProviderContext(BaseModel):
    """Deterministically normalized provider/org/role context for workflow use."""

    provider: ProviderIdentityInput
    organizations: list[ProviderOrganizationInput] = Field(default_factory=list)
    provider_role_relationships: list[ProviderRoleRelationshipInput] = Field(default_factory=list)
    selected_provider_role_relationship: ProviderRoleRelationshipInput | None = None
    selected_organization: ProviderOrganizationInput | None = None
    normalization_mode: Literal[
        "legacy_provider_profile",
        "provider_context_single_relationship",
        "provider_context_explicit_selection",
    ]


class NormalizedPatientContext(BaseModel):
    """Deterministically normalized patient/clinical context for workflow use."""

    patient: PatientIdentityInput
    conditions: list[PatientConditionInput] = Field(default_factory=list)
    medications: list[PatientMedicationInput] = Field(default_factory=list)
    allergies: list[PatientAllergyInput] = Field(default_factory=list)
    selected_condition_for_single_entry: PatientConditionInput | None = None
    selected_medication_for_single_entry: PatientMedicationInput | None = None
    selected_allergy_for_single_entry: PatientAllergyInput | None = None
    planned_medication_entries: list[NormalizedPlannedMedicationEntry] = Field(default_factory=list)
    deferred_additional_medication_count: int = 0
    normalization_mode: Literal[
        "legacy_patient_profile",
        "patient_context_explicit",
    ]


class NormalizedBuildRequest(StageArtifact):
    """Deterministic normalized workflow request."""

    specification: SpecificationSelection
    patient_profile: ProfileReferenceInput
    patient_context: NormalizedPatientContext
    provider_profile: ProfileReferenceInput
    provider_context: NormalizedProviderContext
    request: BundleRequestInput
    workflow_defaults: WorkflowDefaults
    run_label: str


class SpecificationAssetContext(StageArtifact):
    """Workflow wrapper around the first normalized PS-CA asset context."""

    normalized_assets: PscaNormalizedAssetContext


class BundleScaffold(BaseModel):
    """Bundle-level scaffold for the schematic artifact."""

    profile_url: str
    bundle_type: str
    required_entry_placeholder_ids: list[str]
    required_later_fields: list[str] = Field(default_factory=list)


class CompositionScaffold(BaseModel):
    """Composition-level scaffold for the schematic artifact."""

    placeholder_id: str
    profile_url: str
    expected_type_system: str
    expected_type_code: str
    expected_type_display: str
    required_later_fields: list[str] = Field(default_factory=list)


class SectionScaffold(BaseModel):
    """One explicit Composition section scaffold."""

    section_key: str
    slice_name: str
    title: str
    loinc_code: str
    required: bool
    allowed_resource_types: list[str] = Field(default_factory=list)
    entry_placeholder_ids: list[str] = Field(default_factory=list)


class ResourcePlaceholder(BaseModel):
    """Placeholder bundle component required by the schematic."""

    placeholder_id: str
    resource_type: str
    role: str
    profile_url: str | None = None
    required: bool = True
    section_keys: list[str] = Field(default_factory=list)
    required_later_fields: list[str] = Field(default_factory=list)


class SchematicRelationship(BaseModel):
    """Explicit relationship captured in the schematic."""

    relationship_id: str
    relationship_type: str
    source_id: str
    target_id: str
    reference_path: str | None = None
    description: str


class SchematicProviderContextEvidence(BaseModel):
    """Selected provider/org/role context copied into schematic provenance."""

    normalization_mode: Literal[
        "legacy_provider_profile",
        "provider_context_single_relationship",
        "provider_context_explicit_selection",
    ]
    provider_id: str
    provider_display_name: str
    provider_source_type: Literal["stub", "provider_management"]
    selected_organization_id: str | None = None
    selected_organization_display_name: str | None = None
    selected_provider_role_relationship_id: str | None = None
    selected_provider_role_label: str | None = None


class SchematicPatientContextEvidence(BaseModel):
    """Selected patient context copied into schematic provenance."""

    normalization_mode: Literal[
        "legacy_patient_profile",
        "patient_context_explicit",
    ]
    patient_id: str
    patient_display_name: str
    patient_source_type: Literal["stub", "patient_management"]
    administrative_gender_present: bool
    birth_date_present: bool


class SchematicClinicalSectionContextEvidence(BaseModel):
    """Section-level patient clinical context availability recorded for planning inspectability."""

    section_key: str
    available_item_count: int
    selected_single_entry_display_text: str | None = None
    planned_entry_display_texts: list[str] = Field(default_factory=list)
    planned_medication_entries: list[NormalizedPlannedMedicationEntry] = Field(default_factory=list)
    planned_placeholder_count: int
    deferred_additional_item_count: int = 0
    planning_disposition: Literal[
        "legacy_profile_fallback",
        "fixed_single_entry_no_structured_items",
        "fixed_single_entry_selected_item",
        "fixed_single_entry_multiple_items_deferred",
        "bounded_two_entry_selected_first_two",
    ]


class SchematicEvidence(BaseModel):
    """Provenance captured for the generated schematic."""

    selected_example_filename: str
    selected_example_section_titles: list[str] = Field(default_factory=list)
    selected_example_entry_resource_types: list[str] = Field(default_factory=list)
    used_profile_ids: list[str] = Field(default_factory=list)
    used_section_slice_names: list[str] = Field(default_factory=list)
    patient_context: SchematicPatientContextEvidence
    clinical_section_contexts: list[SchematicClinicalSectionContextEvidence] = Field(default_factory=list)
    provider_context: SchematicProviderContextEvidence
    source_refs: list[str] = Field(default_factory=list)


class BundleSchematic(StageArtifact):
    """Structured PS-CA bundle scaffold for downstream planning."""

    generation_basis: Literal["deterministic_psca_foundation_rules"]
    bundle_scaffold: BundleScaffold
    composition_scaffold: CompositionScaffold
    section_scaffolds: list[SectionScaffold]
    resource_placeholders: list[ResourcePlaceholder]
    relationships: list[SchematicRelationship]
    evidence: SchematicEvidence
    omitted_optional_sections: list[str] = Field(default_factory=list)


BuildStepKind = Literal[
    "anchor_resource",
    "support_resource",
    "section_entry_resource",
    "composition_scaffold",
    "composition_finalize",
]
BuildStepDependencyType = Literal[
    "requires_reference_handle",
    "requires_scaffold_ready",
    "requires_section_entries_attached",
]


class BuildStepDependency(BaseModel):
    """Explicit prerequisite relationship for one build step."""

    prerequisite_step_id: str
    dependency_type: BuildStepDependencyType
    reason: str


class BuildStepInput(BaseModel):
    """Expected input context for one build step."""

    input_key: str
    input_type: str
    required: bool
    description: str


class BuildStepOutput(BaseModel):
    """Expected output artifact from one build step."""

    output_key: str
    output_type: str
    description: str


class BuildPlanStep(BaseModel):
    """Ordered resource build step derived from the schematic."""

    step_id: str
    sequence: int
    step_kind: BuildStepKind
    target_placeholder_id: str
    resource_type: str
    profile_url: str | None = None
    owning_section_key: str | None = None
    build_purpose: str
    dependencies: list[BuildStepDependency] = Field(default_factory=list)
    expected_inputs: list[BuildStepInput] = Field(default_factory=list)
    expected_outputs: list[BuildStepOutput] = Field(default_factory=list)
    optional: bool = False


class BuildPlanEvidence(BaseModel):
    """Provenance for the build plan artifact."""

    source_schematic_stage_id: str
    source_schematic_generation_basis: str
    planned_placeholder_ids: list[str] = Field(default_factory=list)
    planned_section_keys: list[str] = Field(default_factory=list)
    relationship_ids_used: list[str] = Field(default_factory=list)
    source_refs: list[str] = Field(default_factory=list)


class BuildPlan(StageArtifact):
    """Structured PS-CA build plan for downstream resource construction."""

    plan_basis: Literal["deterministic_schematic_dependency_plan"]
    composition_strategy: Literal["scaffold_then_incremental_section_finalize"]
    steps: list[BuildPlanStep]
    deferred_items: list[str] = Field(default_factory=list)
    evidence: BuildPlanEvidence


ResourceConstructionMode = Literal["deterministic_content_enriched"]
ResourceConstructionExecutionScope = Literal["full_build", "targeted_repair"]
ResourceConstructionRepairDirectiveScope = Literal["build_step_subset"]
ResourceConstructionRepairDirectiveBasis = Literal["validation_finding_code_map"]
ResourceConstructionExecutionStatus = Literal["scaffold_created", "scaffold_updated"]
ReferenceContributionStatus = Literal["applied"]
ResourceScaffoldState = Literal[
    "base_scaffold_created",
    "references_attached",
    "composition_scaffold_created",
    "sections_attached",
]


class ReferenceContribution(BaseModel):
    """Reference field contribution applied while constructing a scaffold."""

    reference_path: str
    target_placeholder_id: str
    reference_value: str
    status: ReferenceContributionStatus


class DeterministicValueEvidence(BaseModel):
    """Provenance for one deterministic populated field."""

    target_path: str
    source_artifact: str
    source_detail: str


class ResourceConstructionRepairDirective(BaseModel):
    """Deterministic directive for narrowing resource construction repair."""

    directive_basis: ResourceConstructionRepairDirectiveBasis
    scope: ResourceConstructionRepairDirectiveScope
    trigger_finding_codes: list[str] = Field(default_factory=list)
    target_step_ids: list[str] = Field(default_factory=list)
    target_placeholder_ids: list[str] = Field(default_factory=list)
    rationale: str


class ResourceScaffoldArtifact(BaseModel):
    """Partial FHIR-shaped scaffold for a constructed placeholder resource."""

    placeholder_id: str
    resource_type: str
    profile_url: str | None = None
    scaffold_state: ResourceScaffoldState
    fhir_scaffold: dict[str, Any]
    populated_paths: list[str] = Field(default_factory=list)
    deferred_paths: list[str] = Field(default_factory=list)
    source_step_ids: list[str] = Field(default_factory=list)


class ResourceConstructionStepResult(BaseModel):
    """Per-step construction result aligned to the build plan."""

    step_id: str
    step_kind: BuildStepKind
    resource_type: str
    target_placeholder_id: str
    execution_status: ResourceConstructionExecutionStatus
    resource_scaffold: ResourceScaffoldArtifact
    reference_contributions: list[ReferenceContribution] = Field(default_factory=list)
    deterministic_value_evidence: list[DeterministicValueEvidence] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    unresolved_fields: list[str] = Field(default_factory=list)


class ResourceRegistryEntry(BaseModel):
    """Latest scaffold state for a constructed placeholder resource."""

    placeholder_id: str
    resource_type: str
    latest_step_id: str
    current_scaffold: ResourceScaffoldArtifact


class ResourceConstructionEvidence(BaseModel):
    """Provenance for the resource construction stage."""

    source_build_plan_stage_id: str
    source_build_plan_basis: str
    source_schematic_stage_id: str
    planned_step_ids: list[str] = Field(default_factory=list)
    placeholder_traceability_summaries: list[PlaceholderTraceabilitySummary] = Field(default_factory=list)
    source_refs: list[str] = Field(default_factory=list)


class ResourceConstructionStageResult(StageArtifact):
    """Structured scaffold-oriented outputs from the resource construction stage."""

    construction_mode: ResourceConstructionMode
    execution_scope: ResourceConstructionExecutionScope = "full_build"
    applied_repair_directive: ResourceConstructionRepairDirective | None = None
    regenerated_placeholder_ids: list[str] = Field(default_factory=list)
    reused_placeholder_ids: list[str] = Field(default_factory=list)
    step_results: list[ResourceConstructionStepResult]
    step_result_history: list[ResourceConstructionStepResult] = Field(default_factory=list)
    resource_registry: list[ResourceRegistryEntry]
    deferred_items: list[str] = Field(default_factory=list)
    unresolved_items: list[str] = Field(default_factory=list)
    evidence: ResourceConstructionEvidence


CandidateBundleAssemblyMode = Literal["deterministic_registry_bundle_scaffold"]
CandidateBundleState = Literal["candidate_scaffold_assembled"]


class BundleEntryAssemblyResult(BaseModel):
    """Deterministic assembly metadata for one bundle entry."""

    sequence: int
    placeholder_id: str
    resource_type: str
    full_url: str
    required_by_bundle_scaffold: bool
    source_registry_step_id: str
    scaffold_state: ResourceScaffoldState
    entry_path: str


class CandidateBundleArtifact(BaseModel):
    """Candidate bundle scaffold assembled from constructed resource scaffolds."""

    bundle_id: str
    profile_url: str
    bundle_type: str
    bundle_state: CandidateBundleState
    entry_count: int
    fhir_bundle: dict[str, Any]
    populated_paths: list[str] = Field(default_factory=list)
    deferred_paths: list[str] = Field(default_factory=list)
    deterministic_value_evidence: list[DeterministicValueEvidence] = Field(default_factory=list)


class CandidateBundleEvidence(BaseModel):
    """Provenance for the candidate bundle stage."""

    source_resource_construction_stage_id: str
    source_schematic_stage_id: str
    source_build_plan_stage_id: str
    required_entry_placeholder_ids: list[str] = Field(default_factory=list)
    ordered_placeholder_ids: list[str] = Field(default_factory=list)
    planned_medication_placeholder_ids: list[str] = Field(default_factory=list)
    assembled_medication_placeholder_ids: list[str] = Field(default_factory=list)
    placeholder_traceability_summaries: list[PlaceholderTraceabilitySummary] = Field(default_factory=list)
    source_refs: list[str] = Field(default_factory=list)


class CandidateBundleResult(StageArtifact):
    """Structured bundle-finalization artifact for the candidate bundle scaffold."""

    assembly_mode: CandidateBundleAssemblyMode
    candidate_bundle: CandidateBundleArtifact
    entry_assembly: list[BundleEntryAssemblyResult]
    deferred_items: list[str] = Field(default_factory=list)
    unresolved_items: list[str] = Field(default_factory=list)
    evidence: CandidateBundleEvidence


class ValidationReport(StageArtifact):
    """Structured validation report with separated standards and workflow channels."""

    overall_status: ValidationStatus
    standards_validation: StandardsValidationResult
    workflow_validation: WorkflowValidationResult
    error_count: int
    warning_count: int
    information_count: int
    deferred_validation_areas: list[str] = Field(default_factory=list)
    evidence: ValidationEvidence


RepairOverallDecision = Literal[
    "complete_no_repair_needed",
    "repair_recommended",
    "external_validation_pending",
    "human_review_recommended",
]
RepairRouteTarget = Literal[
    "none_required",
    "resource_construction",
    "bundle_finalization",
    "build_plan_or_schematic",
    "standards_validation_external",
    "human_intervention",
]
RepairRecommendedNextStage = Literal["none", "resource_construction", "bundle_finalization", "build_plan"]


class RepairFindingRoute(BaseModel):
    """Deterministic routing recommendation for one validation finding."""

    channel: ValidationChannel
    severity: ValidationSeverity
    finding_code: str
    route_target: RepairRouteTarget
    recommended_next_stage: RepairRecommendedNextStage
    actionable: bool
    reason: str


class RepairDecisionEvidence(BaseModel):
    """Provenance for the repair decision stage."""

    source_validation_stage_id: str
    source_overall_validation_status: ValidationStatus
    routed_finding_codes: list[str] = Field(default_factory=list)
    source_refs: list[str] = Field(default_factory=list)


class RepairDecisionResult(StageArtifact):
    """Structured repair decision and routing recommendation."""

    overall_decision: RepairOverallDecision
    recommended_target: RepairRouteTarget
    recommended_next_stage: RepairRecommendedNextStage
    recommended_resource_construction_repair_directive: ResourceConstructionRepairDirective | None = None
    finding_routes: list[RepairFindingRoute] = Field(default_factory=list)
    deferred_external_dependencies: list[str] = Field(default_factory=list)
    evidence: RepairDecisionEvidence
    rationale: str


RepairExecutionMode = Literal["single_targeted_retry_pass"]
RepairExecutionOutcome = Literal["executed", "deferred", "not_needed", "unsupported"]


class RepairExecutionEvidence(BaseModel):
    """Provenance for the repair execution stage."""

    source_repair_decision_stage_id: str
    source_validation_stage_id: str
    source_recommended_target: RepairRouteTarget
    source_overall_decision: RepairOverallDecision
    rerun_stage_ids: list[str] = Field(default_factory=list)
    regenerated_artifact_keys: list[str] = Field(default_factory=list)
    source_refs: list[str] = Field(default_factory=list)


class RepairExecutionResult(StageArtifact):
    """Structured retry execution result for one bounded repair pass."""

    execution_mode: RepairExecutionMode
    execution_outcome: RepairExecutionOutcome
    retry_eligible: bool
    requested_target: RepairRouteTarget
    executed_target: RepairRouteTarget | None = None
    recommended_next_stage: RepairRecommendedNextStage
    attempt_count: int
    rerun_stage_ids: list[str] = Field(default_factory=list)
    regenerated_artifact_keys: list[str] = Field(default_factory=list)
    applied_resource_construction_repair_directive: ResourceConstructionRepairDirective | None = None
    post_retry_resource_construction: ResourceConstructionStageResult | None = None
    post_retry_candidate_bundle: CandidateBundleResult | None = None
    post_retry_validation_report: ValidationReport | None = None
    post_retry_repair_decision: RepairDecisionResult | None = None
    deferred_reason: str | None = None
    unsupported_reason: str | None = None
    evidence: RepairExecutionEvidence
    rationale: str


class WorkflowEffectiveOutcome(BaseModel):
    """Canonical effective final artifact set after the bounded retry pass."""

    artifact_source: Literal["initial_run", "post_retry"]
    resource_construction: ResourceConstructionStageResult
    candidate_bundle: CandidateBundleResult
    validation_report: ValidationReport
    repair_decision: RepairDecisionResult


class WorkflowSkeletonRunResult(BaseModel):
    """Final nested output yielded by the skeleton workflow."""

    workflow_name: str
    workflow_version: str
    stage_order: list[str]
    normalized_request: NormalizedBuildRequest
    specification_asset_context: SpecificationAssetContext
    bundle_schematic: BundleSchematic
    build_plan: BuildPlan
    resource_construction: ResourceConstructionStageResult
    candidate_bundle: CandidateBundleResult
    validation_report: ValidationReport
    repair_decision: RepairDecisionResult
    repair_execution: RepairExecutionResult
    effective_outcome: WorkflowEffectiveOutcome
